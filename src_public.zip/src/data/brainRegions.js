export const brainRegions = [
  {
    id: 'cerebral-cortex',
    name: 'Cerebral Cortex',
    position: [0, 2, 0],
    size: 1.2,
    color: '#ff6b6b',
    hotspot: [0, 2, 0],
    description: 'The outer layer of the brain responsible for higher-order thinking, memory, attention, awareness, thought, language, and consciousness.',
    functions: [
      'Higher-order thinking and reasoning',
      'Memory and learning',
      'Language processing',
      'Sensory perception',
      'Motor control',
      'Decision making'
    ]
  },
  {
    id: 'frontal-lobe',
    name: 'Frontal Lobe',
    position: [0, 1.5, 2],
    size: 3.0,
    color: '#4ecdc4',
    hotspot: [0, 1.5, 18],
    description: 'Located at the front of the brain, responsible for executive functions, decision making, and personality.',
    functions: [
      'Executive functions',
      'Decision making',
      'Problem solving',
      'Planning and organization',
      'Personality',
      'Motor control'
    ]
  },
  {
    id: 'parietal-lobe',
    name: 'Parietal Lobe',
    position: [2, 1, 0],
    size: 2.8,
    color: '#45b7d1',
    hotspot: [15, 6, 0],
    description: 'Processes sensory information and spatial awareness.',
    functions: [
      'Spatial awareness',
      'Sensory integration',
      'Touch perception',
      'Visual processing',
      'Mathematical reasoning'
    ]
  },
  {
    id: 'temporal-lobe',
    name: 'Temporal Lobe',
    position: [-2, 0.5, 0],
    size: 2.8,
    color: '#96ceb4',
    hotspot: [-15, 1.5, 0],
    description: 'Involved in auditory processing, memory, and language comprehension.',
    functions: [
      'Auditory processing',
      'Memory formation',
      'Language comprehension',
      'Emotion processing',
      'Face recognition'
    ]
  },
  {
    id: 'occipital-lobe',
    name: 'Occipital Lobe',
    position: [0, 0.5, -2],
    size: 2.5,
    color: '#feca57',
    hotspot: [0, 1.5, -18],
    description: 'Primary visual processing center of the brain.',
    functions: [
      'Visual processing',
      'Color recognition',
      'Motion detection',
      'Depth perception',
      'Visual memory'
    ]
  },
  {
    id: 'cerebellum',
    name: 'Cerebellum',
    position: [0, -1.5, 0],
    size: 2.5,
    color: '#ff9ff3',
    hotspot: [0, -12, -8],
    description: 'Coordinates movement, balance, and motor learning.',
    functions: [
      'Movement coordination',
      'Balance and posture',
      'Motor learning',
      'Fine motor control',
      'Timing and rhythm'
    ]
  },
  {
    id: 'brain-stem',
    name: 'Brain Stem',
    position: [0, -2.5, 0],
    size: 1.5,
    color: '#54a0ff',
    hotspot: [0, -12, 0],
    description: 'Controls basic life functions and connects brain to spinal cord.',
    functions: [
      'Breathing regulation',
      'Heart rate control',
      'Blood pressure',
      'Sleep cycles',
      'Consciousness'
    ]
  },
  {
    id: 'hippocampus',
    name: 'Hippocampus',
    position: [-1, 0, 1],
    size: 1.0,
    color: '#5f27cd',
    hotspot: [-4, 0, 4],
    description: 'Critical for memory formation and spatial navigation.',
    functions: [
      'Memory formation',
      'Spatial navigation',
      'Learning',
      'Emotional regulation',
      'Context processing'
    ]
  },
  {
    id: 'amygdala',
    name: 'Amygdala',
    position: [1, 0, 1],
    size: 1.0,
    color: '#ff6348',
    hotspot: [4, 0, 4],
    description: 'Processes emotions, especially fear and aggression.',
    functions: [
      'Fear processing',
      'Emotional memory',
      'Aggression',
      'Social behavior',
      'Stress response'
    ]
  },
  {
    id: 'thalamus',
    name: 'Thalamus',
    position: [0, 0, 0.5],
    size: 0.6,
    color: '#00d2d3',
    hotspot: [0, 0, 0.5],
    description: 'Relay station for sensory and motor signals.',
    functions: [
      'Sensory relay',
      'Motor control',
      'Consciousness',
      'Sleep regulation',
      'Attention'
    ]
  },
  {
    id: 'hypothalamus',
    name: 'Hypothalamus',
    position: [0, -0.5, 0.8],
    size: 1.0,
    color: '#ff9f43',
    hotspot: [0, -6, 6],
    description: 'Controls autonomic functions and hormone production.',
    functions: [
      'Temperature regulation',
      'Hunger and thirst',
      'Hormone production',
      'Circadian rhythms',
      'Emotional responses'
    ]
  },
  {
    id: 'corpus-callosum',
    name: 'Corpus Callosum',
    position: [0, 1, 0],
    size: 0.4,
    color: '#a55eea',
    hotspot: [0, 1.2, 0],
    description: 'Connects the left and right hemispheres of the brain.',
    functions: [
      'Interhemispheric communication',
      'Coordination between hemispheres',
      'Information transfer',
      'Unified perception',
      'Complex cognitive tasks'
    ]
  }
]; 